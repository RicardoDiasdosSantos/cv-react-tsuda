import styles from "./styles.css";
import Perfil from "../assets/foto.png";

export default function LadoEsq () {
    return (
        <div className="colEsq">
            <div className="perfil">
                <div className="foto">
                    <img src={Perfil} alt="foto de perfil" />
                </div>
                <h1> Ricardo Dias dos Santos </h1>
                <p> 
                    Telefone: 
                    <span> (11) 91111-2222 </span> 
                </p>
                <p> 
                    E-mail: 
                    <span> diasricardo2001@gmail.com </span> 
                </p>
                <p> 
                    Data de nascimento: 
                    <span> 08/03/2001 </span> 
                </p>
                <p> 
                    LinkedIn: 
                    <a href="https://www.linkedin.com/in/ricardo-dias-802557192/"> https://www.linkedin.com/in/ricardo-dias-802557192/ </a> 
                </p>
                <p> 
                    GitHub: 
                    <a href="https://github.com/RicardoDiasdosSantos"> https://github.com/RicardoDiasdosSantos </a> 
                </p>   
            </div>
            
            <div className="conhecimentos">
                <h2> Conhecimentos </h2>
                <ul>
                    <li> Java </li>
                    <li> React </li>
                    <li> Automação com Cypress </li>
                    <li> Configuração de Pipeline Jenkins </li>
                </ul>
            </div>
        </div>
    );
}