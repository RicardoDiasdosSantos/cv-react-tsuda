import styles from "./styles.css";

export default function Idiomas (){
    return(
        <div className="teste">
            <div className="idiomas">
            <h2> Idiomas </h2>
            <table>
                <thead>
                    <tr>
                        <th> &nbsp; </th>
                        <th> Leitura </th>
                        <th> Escrita </th>
                        <th> Conversão </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                       <th> Inglês </th>
                       <th> Médio </th> 
                       <th> Ruim </th>
                       <th> Bom </th>
                    </tr>
                    <tr>
                        <th> Mandarin </th>
                        <th> Ruim </th>
                        <th> Ruim </th>
                        <th> Ruim </th>
                    </tr>
                    <tr>
                        <th> Português </th>
                        <th> Bom </th>
                        <th> Bom </th>
                        <th> Bom </th>
                    </tr>
                </tbody>
            </table>
        </div>
        </div>
    );
}