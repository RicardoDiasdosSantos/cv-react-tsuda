import styles from "./styles.css";

export default function Experiencia() {
  return (
    <div className="colDir">

      <div className="experiencias">
        <h2> Experiências profissionais </h2>
        <h3>Amix Serviços de Informatica</h3>
        <p>
          <strong> Operador de Informatica JR </strong>
        </p>
        <p>Período: De 01/2021 até 11/2021</p>
        <h3>Orange Testing</h3>
        <p>
          <strong> Analista de Testes Jr </strong>
        </p>
        <p>Período: Desde 12/2021</p>
      </div>

      <div className="formacao">
        <h2>Formação acadêmica</h2>
        <ul>
            <li>
                <h3> Analista e Desenvolvimento de Sistemas </h3>
                <p> <strong> Centro Universitario Senac Santo Amaro </strong> </p>
            </li>
        </ul>
      </div>
    </div>
  );
}